package com.obb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObbApplication.class, args);
	}

}
