package com.obb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObbApplicationTests {

	@Test
	void contextLoads() {
	}

}
